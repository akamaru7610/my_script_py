class MyLib(object):
    def get_name(self):
        return "my_lib"
