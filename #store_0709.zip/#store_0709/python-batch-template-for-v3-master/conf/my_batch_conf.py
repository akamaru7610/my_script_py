class MyBatchConf(object):
    key1 = "key1_value"
    key2 = True
